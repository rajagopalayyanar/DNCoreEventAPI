﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventAPI.Infrastructure;
using EventAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : Controller
    {
        private EventDbContext db;
        public EventsController(EventDbContext dbContext)
        {
            db = dbContext;
        }
        [HttpGet("",Name="GetAllEvents")]
        public ActionResult<IEnumerable<EventData>> GetEvents()
        {
            var events = db.Events.ToList();
            return Ok(events);
        }
        [HttpGet("{id:int:min(1)}", Name = "GetEventById")]
        public async Task<ActionResult<IEnumerable<EventData>>> GetEventByIdAsync(int id)
        {
            var events = await db.Events.FindAsync(id);
            return Ok(events);
        }

        [HttpPost("",Name="AddEvent")]
        public ActionResult<EventData> AddEvent(EventData item)
        {
            TryValidateModel(item);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                db.Events.Add(item);
                db.SaveChanges();
                return Created("", item);
            }
        }
        [HttpPost("", Name = "AddEvent")]
        public async Task<ActionResult<EventData>> AddEventAsync(EventData item)
        {
            TryValidateModel(item);
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                await db.Events.AddAsync(item);
                await db.SaveChangesAsync();
                return CreatedAtRoute("GetEventById", new { id = item.Id },item);
            }
        }
    }
}